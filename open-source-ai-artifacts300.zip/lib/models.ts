import { createAnthropic } from '@ai-sdk/anthropic'
import { createFireworks } from '@ai-sdk/fireworks'
import { createGoogleGenerativeAI } from '@ai-sdk/google'
import { createVertex } from '@ai-sdk/google-vertex'
import { createMistral } from '@ai-sdk/mistral'
import { createOpenAI } from '@ai-sdk/openai'
import { createOllama } from 'ollama-ai-provider'

export type LLMModel = {
  id: string
  name: string
  provider: string
  providerId: string
}

export type LLMModelConfig = {
  model?: string
  apiKey?: string
  baseURL?: string
  temperature?: number
  topP?: number
  topK?: number
  frequencyPenalty?: number
  presencePenalty?: number
  maxTokens?: number
}

export function getModelClient(model: LLMModel, config: LLMModelConfig) {
  const { id: modelNameString, providerId } = model
  const { apiKey, baseURL } = config

  const anthropicModelReplacements: Record<string, string> = {
    'claude-3-5-sonnet-latest': 'claude-3-5-haiku-20241022',
    'claude-3-5-haiku-latest': 'claude-3-5-haiku-20241022',
    'claude-3-7-sonnet-latest': 'claude-3-7-sonnet-20250219',
    'claude-sonnet-4-20250514': 'claude-sonnet-4-5-20250929',
    'claude-opus-4-20250514': 'claude-opus-4-1-20250805',
  }

  const resolvedModelNameString =
    providerId === 'anthropic'
      ? anthropicModelReplacements[modelNameString] ?? modelNameString
      : modelNameString

  const providerConfigs = {
    anthropic: () => createAnthropic({ apiKey, baseURL })(resolvedModelNameString),
    openai: () => createOpenAI({ apiKey: apiKey || process.env.OPENAI_API_KEY, baseURL })(modelNameString),
    google: () =>
      createGoogleGenerativeAI({ apiKey, baseURL })(resolvedModelNameString),
    mistral: () => createMistral({ apiKey, baseURL })(resolvedModelNameString),
    groq: () =>
      createOpenAI({
        apiKey: apiKey || process.env.GROQ_API_KEY,
        baseURL: baseURL || 'https://api.groq.com/openai/v1',
      })(resolvedModelNameString),
    togetherai: () =>
      createOpenAI({
        apiKey: apiKey || process.env.TOGETHER_API_KEY,
        baseURL: baseURL || 'https://api.together.xyz/v1',
      })(resolvedModelNameString),
    ollama: () => createOllama({ baseURL })(resolvedModelNameString),
    fireworks: () =>
      createFireworks({
        apiKey: apiKey || process.env.FIREWORKS_API_KEY,
        baseURL: baseURL || 'https://api.fireworks.ai/inference/v1',
      })(resolvedModelNameString),
    vertex: () =>
      createVertex({
        googleAuthOptions: {
          credentials: JSON.parse(
            process.env.GOOGLE_VERTEX_CREDENTIALS || '{}',
          ),
        },
      })(resolvedModelNameString),
    xai: () =>
      createOpenAI({
        apiKey: apiKey || process.env.XAI_API_KEY,
        baseURL: baseURL || 'https://api.x.ai/v1',
      })(resolvedModelNameString),
    deepseek: () =>
      createOpenAI({
        apiKey: apiKey || process.env.DEEPSEEK_API_KEY,
        baseURL: baseURL || 'https://api.deepseek.com/v1',
      })(resolvedModelNameString),
  }

  const createClient =
    providerConfigs[providerId as keyof typeof providerConfigs]

  if (!createClient) {
    throw new Error(`Unsupported provider: ${providerId}`)
  }

  return createClient()
}
