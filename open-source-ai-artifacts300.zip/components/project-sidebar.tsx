"use client"

import { useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { Plus, Trash2, Pencil, X, CheckCircle2, Folder, FolderOpen } from 'lucide-react'

export type Project = {
  id: string
  name: string
  createdAt: number
  updatedAt: number
}


function uuid() {
  if (typeof crypto !== 'undefined' && (crypto as any).randomUUID) {
    return (crypto as any).randomUUID()
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
}

export function ProjectSidebar({
  open,
  onOpenChange,
  projects,
  setProjects,
  currentProjectId,
  setCurrentProjectId,
  onProjectSwitched,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  projects: Project[]
  setProjects: (p: Project[]) => void
  currentProjectId: string | undefined
  setCurrentProjectId: (id: string) => void
  onProjectSwitched: () => void
}) {
  const [creating, setCreating] = useState(false)
  const [newName, setNewName] = useState('')
  const [renamingId, setRenamingId] = useState<string | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)

  function stateKey(id: string) {
    return `project:${id}:state`
  }

  useEffect(() => {
    if (!open) {
      setCreating(false)
      setNewName('')
      setRenamingId(null)
      setRenameValue('')
      setConfirmDeleteId(null)
    }
  }, [open])

  const sorted = useMemo(
    () => [...projects].sort((a, b) => b.updatedAt - a.updatedAt),
    [projects],
  )

  function createProject() {
    const name = newName.trim() || `Project ${projects.length + 1}`
    const now = Date.now()
    const p: Project = { id: uuid(), name, createdAt: now, updatedAt: now }
    const next = [p, ...projects]
    setProjects(next)
    setCurrentProjectId(p.id)
    onProjectSwitched()
    setCreating(false)
    setNewName('')
  }

  function startRename(id: string, name: string) {
    setRenamingId(id)
    setRenameValue(name)
  }

  function commitRename(id: string) {
    const value = renameValue.trim()
    if (!value) return
    const next = projects.map((p) =>
      p.id === id ? { ...p, name: value, updatedAt: Date.now() } : p,
    )
    setProjects(next)
    setRenamingId(null)
    setRenameValue('')
  }

  function requestDelete(id: string) {
    setConfirmDeleteId(id)
  }

  function performDelete(id: string) {
    const next = projects.filter((p) => p.id !== id)
    if (next.length === 0) {
      // Prevent deleting the last project
      setConfirmDeleteId(null)
      return
    }
    setProjects(next)
    if (currentProjectId === id) {
      const fallback = next[0]
      setCurrentProjectId(fallback ? fallback.id : '')
      onProjectSwitched()
    }
    // Remove state and versions for deleted project
    try {
      localStorage.removeItem(stateKey(id))
    } catch {}
    setConfirmDeleteId(null)
  }

  function selectProject(id: string) {
    if (id === currentProjectId) return
    setCurrentProjectId(id)
    onProjectSwitched()
  }

  function saveSnapshot() {
    if (!currentProjectId) return
    const state = onGetCurrentState()
    const versions = readVersions(currentProjectId)
    const snap: ProjectSnapshot = {
      id: uuid(),
      createdAt: Date.now(),
      label: `Snapshot ${versions.length + 1}`,
      state,
    }
    const next = [snap, ...versions].slice(0, 50)
    writeVersions(currentProjectId, next)
  }

  function restoreSnapshot(id: string) {
    if (!currentProjectId) return
    const versions = readVersions(currentProjectId)
    const found = versions.find((v) => v.id === id)
    if (!found) return
    onRestore(found.state)
  }

  function deleteSnapshot(id: string) {
    if (!currentProjectId) return
    const versions = readVersions(currentProjectId)
    const next = versions.filter((v) => v.id !== id)
    writeVersions(currentProjectId, next)
  }

  return (
    <div
      className={`fixed inset-0 z-40 ${open ? 'pointer-events-auto' : 'pointer-events-none'}`}
      aria-hidden={!open}
    >
      <div
        className={`absolute inset-0 bg-black/30 transition-opacity ${open ? 'opacity-100' : 'opacity-0'}`}
        onClick={() => onOpenChange(false)}
      />
      <div
        className={`absolute left-0 top-0 h-full w-[320px] bg-popover border-r shadow-xl transition-transform ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-3 border-b">
          <div className="flex items-center gap-2">
            <Folder className="h-4 w-4" />
            <span className="font-semibold text-sm">Projects</span>
          </div>
          <TooltipProvider>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Close</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="p-3 flex gap-2">
          <Input
            placeholder="New project name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') createProject()
            }}
          />
          <TooltipProvider>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <Button onClick={createProject} variant="default" size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Create</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Separator />
        <div className="flex flex-col gap-1 p-2 overflow-y-auto h-[calc(100%-110px)]">
          {sorted.length === 0 && (
            <div className="text-xs text-muted-foreground p-3">No projects. Create one above.</div>
          )}
          {sorted.map((p) => {
            const isCurrent = p.id === currentProjectId
            const isRenaming = renamingId === p.id
            return (
              <div
                key={p.id}
                className={`group flex items-center gap-2 px-2 py-1 rounded-md border ${
                  isCurrent ? 'bg-muted border-muted' : 'hover:bg-muted'
                }`}
              >
                <button
                  className="flex-1 text-left flex items-center gap-2 overflow-hidden"
                  onClick={() => selectProject(p.id)}
                >
                  {isCurrent ? (
                    <FolderOpen className="h-4 w-4 text-primary" />
                  ) : (
                    <Folder className="h-4 w-4 text-muted-foreground" />
                  )}
                  {isRenaming ? (
                    <Input
                      autoFocus
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') commitRename(p.id)
                        if (e.key === 'Escape') {
                          setRenamingId(null)
                          setRenameValue('')
                        }
                      }}
                    />
                  ) : (
                    <span className="truncate text-sm">{p.name}</span>
                  )}
                </button>
                {isRenaming ? (
                  <Button variant="ghost" size="icon" onClick={() => commitRename(p.id)}>
                    <CheckCircle2 className="h-4 w-4" />
                  </Button>
                ) : (
                  <>
                    <TooltipProvider>
                      <Tooltip delayDuration={0}>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => startRename(p.id, p.name)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Rename</TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <TooltipProvider>
                      <Tooltip delayDuration={0}>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            disabled={projects.length <= 1}
                            onClick={() => requestDelete(p.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Delete</TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </>
                )}
              </div>
            )
          })}
        </div>
        {confirmDeleteId && (
          <div className="absolute bottom-0 left-0 right-0 border-t bg-popover p-3">
            <div className="text-sm mb-2">Are you sure you want to delete this project? This cannot be undone.</div>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setConfirmDeleteId(null)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={() => performDelete(confirmDeleteId)}>
                Delete
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
