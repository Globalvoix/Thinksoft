"use client"

import { useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

declare global {
  interface Window {
    paypal?: any
  }
}

export function PaymentDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  useEffect(() => {
    if (!open) return
    if (typeof window === 'undefined') return
    const paypal = window.paypal
    if (paypal?.HostedButtons) {
      try {
        paypal
          .HostedButtons({ hostedButtonId: 'S3SME8ZGFA8WL' })
          .render('#paypal-container-S3SME8ZGFA8WL')
      } catch {}
    }
  }, [open])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Subscription required</DialogTitle>
          <DialogDescription>
            Due to high demand, we are currently accepting paid users only. Please
            complete your subscription below to continue.
          </DialogDescription>
        </DialogHeader>
        <div id="paypal-container-S3SME8ZGFA8WL" />
      </DialogContent>
    </Dialog>
  )
}
