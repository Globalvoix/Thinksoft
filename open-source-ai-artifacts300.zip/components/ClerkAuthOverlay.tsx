"use client"

import { useAuth, useSignIn, useSignUp } from '@clerk/nextjs'
import { useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2, Mail, KeyRound, CheckCircle2, AlertCircle } from 'lucide-react'

export default function ClerkAuthOverlay() {
  const { isLoaded: signInLoaded, signIn, setActive } = useSignIn()
  const { isLoaded: signUpLoaded, signUp } = useSignUp()
  const { isSignedIn } = useAuth()

  const [mode, setMode] = useState<'signIn' | 'signUp'>('signIn')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [code, setCode] = useState('')
  const [awaitingVerification, setAwaitingVerification] = useState(false)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setError(null); setMessage(null)
  }, [mode])

  const disabled = useMemo(
    () => loading || !signInLoaded || !signUpLoaded,
    [loading, signInLoaded, signUpLoaded],
  )

  async function handleSignIn(e: React.FormEvent) {
    e.preventDefault()
    if (!signIn) return
    setLoading(true); setError(null)
    try {
      const res = await signIn.create({ identifier: email, password })
      if (res?.status === 'complete') {
        await setActive?.({ session: res.createdSessionId })
      }
    } catch (err: any) {
      const code = err?.errors?.[0]?.code || ''
      if (code.includes('form_identifier_not_found')) {
        setMode('signUp')
        setMessage('No account found. Create one to continue.')
      } else if (code.includes('form_password_incorrect')) {
        setError('Incorrect password. Try again.')
      } else {
        setError(err?.errors?.[0]?.message || 'Sign in failed.')
      }
    } finally {
      setLoading(false)
    }
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault()
    if (!signUp) return
    setLoading(true); setError(null); setMessage(null)
    try {
      const res = await signUp.create({ emailAddress: email, password })
      if (res.status === 'complete') {
        await setActive?.({ session: res.createdSessionId })
        return
      }
      // start email verification if required
      await signUp.prepareEmailAddressVerification({ strategy: 'email_code' })
      setAwaitingVerification(true)
      setMessage('We\'ve sent a verification code to your email.')
    } catch (err: any) {
      const code = err?.errors?.[0]?.code || ''
      if (code.includes('form_identifier_exists')) {
        setMode('signIn')
        setMessage('Account already exists. Please sign in.')
      } else {
        setError(err?.errors?.[0]?.message || 'Sign up failed.')
      }
    } finally {
      setLoading(false)
    }
  }

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault()
    if (!signUp) return
    setLoading(true); setError(null)
    try {
      const res = await signUp.attemptEmailAddressVerification({ code })
      if (res.status === 'complete') {
        await setActive?.({ session: res.createdSessionId })
      }
    } catch (err: any) {
      setError(err?.errors?.[0]?.message || 'Invalid code')
    } finally {
      setLoading(false)
    }
  }

  if (isSignedIn) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="w-full max-w-md rounded-2xl overflow-hidden bg-background/95 backdrop-blur supports-[backdrop-filter]:backdrop-blur-xl border">
        <div className="p-6 space-y-4">
          {message && (
            <div className="flex items-center gap-2 text-green-600 text-sm"><CheckCircle2 className="h-4 w-4" />{message}</div>
          )}
          {error && (
            <div className="flex items-center gap-2 text-red-600 text-sm"><AlertCircle className="h-4 w-4" />{error}</div>
          )}
          {mode === 'signIn' && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="email" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required className="pl-10" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required className="pl-10" />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={disabled}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Sign In
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                Don’t have an account?{' '}<button type="button" className="underline" onClick={()=>setMode('signUp')}>Sign up</button>
              </p>
            </form>
          )}

          {mode === 'signUp' && !awaitingVerification && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="email" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required className="pl-10" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required className="pl-10" />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={disabled}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Create account
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                Already have an account?{' '}<button type="button" className="underline" onClick={()=>setMode('signIn')}>Sign in</button>
              </p>
            </form>
          )}

          {mode === 'signUp' && awaitingVerification && (
            <form onSubmit={handleVerify} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">Verification code</Label>
                <Input id="code" value={code} onChange={(e)=>setCode(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={disabled}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Verify & continue
              </Button>
              <p className="text-center text-xs text-muted-foreground">We sent a 6-digit code to {email}</p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
