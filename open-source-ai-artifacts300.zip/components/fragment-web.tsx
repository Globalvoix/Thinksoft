import { CopyButton } from './ui/copy-button'
import { Button } from '@/components/ui/button'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { ExecutionResultWeb } from '@/lib/types'
import { ExternalLink, RotateCw } from 'lucide-react'
import { useMemo, useState } from 'react'

export function FragmentWeb({ result }: { result: ExecutionResultWeb }) {
  const [iframeKey, setIframeKey] = useState(0)
  const [hasError, setHasError] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)
  if (!result) return null

  function refreshIframe() {
    setHasError(false)
    setIsLoaded(false)
    setIframeKey((prevKey) => prevKey + 1)
  }

  const iframeAllow = useMemo(
    () =>
      [
        'accelerometer',
        'autoplay',
        'camera',
        'clipboard-read',
        'clipboard-write',
        'display-capture',
        'encrypted-media',
        'fullscreen',
        'geolocation',
        'gyroscope',
        'magnetometer',
        'microphone',
        'midi',
        'payment',
        'picture-in-picture',
        'publickey-credentials-get',
        'screen-wake-lock',
        'web-share',
        'xr-spatial-tracking',
      ].join('; '),
    [],
  )

  return (
    <div className="flex flex-col w-full h-full">
      <div className="relative h-full w-full">
        {!isLoaded && !hasError && (
          <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">
            Starting preview...
          </div>
        )}
        {hasError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-sm text-muted-foreground">
            <div>Preview failed to load. The app may still be starting.</div>
            <Button size="sm" variant="secondary" onClick={refreshIframe}>
              Retry
            </Button>
          </div>
        )}
        <iframe
          key={iframeKey}
          className="h-full w-full"
          sandbox="allow-forms allow-scripts allow-same-origin allow-modals allow-popups allow-popups-to-escape-sandbox allow-presentation allow-pointer-lock allow-top-navigation-by-user-activation"
          allow={iframeAllow}
          allowFullScreen
          loading="lazy"
          src={result.url}
          onError={() => setHasError(true)}
          onLoad={() => setIsLoaded(true)}
        />
      </div>
      <div className="p-2 border-t">
        <div className="flex items-center bg-muted dark:bg-white/10 rounded-2xl">
          <TooltipProvider>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <Button
                  variant="link"
                  className="text-muted-foreground"
                  onClick={refreshIframe}
                >
                  <RotateCw className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Refresh</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <span className="text-muted-foreground text-xs flex-1 text-ellipsis overflow-hidden whitespace-nowrap">
            {result.url}
          </span>
          <TooltipProvider>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <CopyButton
                  variant="link"
                  content={result.url}
                  className="text-muted-foreground"
                />
              </TooltipTrigger>
              <TooltipContent>Copy URL</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <Button
                  asChild
                  variant="link"
                  className="text-muted-foreground"
                >
                  <a href={result.url} target="_blank" rel="noreferrer noopener">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Open in new tab</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  )
}
