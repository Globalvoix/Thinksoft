import Auth, { ViewType } from './auth'
import Logo from './logo'
import { validateEmail } from '@/app/actions/validate-email'
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { VisuallyHidden } from '@radix-ui/react-visually-hidden'
import { SupabaseClient } from '@supabase/supabase-js'

export function AuthDialog({
  open,
  setOpen,
  supabase,
  view,
}: {
  open: boolean
  setOpen: (open: boolean) => void
  supabase: SupabaseClient
  view: ViewType
}) {
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-6xl p-0 overflow-hidden rounded-2xl">
        <VisuallyHidden>
          <DialogTitle>Sign in to Fragments</DialogTitle>
          <DialogDescription>
            Sign in or create an account to access Fragments
          </DialogDescription>
        </VisuallyHidden>
        <div className="grid grid-cols-1 md:grid-cols-2 w-full h-full">
          <div className="hidden md:block relative">
            {/* Left visual */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F1d734cd0ef68491eb64e3e5bf6a74b6f%2Ff5f2bf664de4479196be8c464c36ff0d?format=webp&width=800"
              alt="Auth visual"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-black/60 via-black/10 to-transparent" />
          </div>
          <div className="p-8 md:p-12 bg-background/90 backdrop-blur supports-[backdrop-filter]:backdrop-blur-xl">
            <h1 className="flex items-center gap-3 text-2xl font-bold mb-6">
              <div className="flex items-center justify-center rounded-md shadow-md bg-black p-2">
                <Logo className="text-white w-6 h-6" />
              </div>
              Welcome back
            </h1>
            <div className="w-full max-w-md">
              <Auth
                supabaseClient={supabase}
                view={view}
                providers={[]}
                socialLayout="horizontal"
                onSignUpValidate={validateEmail}
                metadata={{
                  is_fragments_user: true,
                }}
              />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
