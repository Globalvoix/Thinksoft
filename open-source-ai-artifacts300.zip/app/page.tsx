'use client'

import { Chat } from '@/components/chat'
import { ChatInput } from '@/components/chat-input'
import { ChatPicker } from '@/components/chat-picker'
import { NavBar } from '@/components/navbar'
import { Preview } from '@/components/preview'
import ClerkAuthOverlay from '@/components/ClerkAuthOverlay'
import { Project, ProjectSidebar } from '@/components/project-sidebar'
import { PaymentDialog } from '@/components/payment-dialog'
import { Message, toAISDKMessages, toMessageImage } from '@/lib/messages'
import { LLMModelConfig } from '@/lib/models'
import modelsList from '@/lib/models.json'
import { FragmentSchema, fragmentSchema as schema } from '@/lib/schema'
import templates, { TemplateId } from '@/lib/templates'
import { ExecutionResult } from '@/lib/types'
import { DeepPartial } from 'ai'
import { experimental_useObject as useObject } from 'ai/react'
import { usePostHog } from 'posthog-js/react'
import { SetStateAction, useEffect, useRef, useState } from 'react'
import { useLocalStorage } from 'usehooks-ts'
import { SignedOut, useUser, useAuth as useClerkAuth } from '@clerk/nextjs'

type StructuredClone = <T>(value: T) => T

const cloneDeep = <T,>(value: T): T => {
  if (value === undefined || value === null) {
    return value
  }

  const structuredCloneFn = (globalThis as typeof globalThis & {
    structuredClone?: StructuredClone
  }).structuredClone

  if (typeof structuredCloneFn === 'function') {
    return structuredCloneFn(value)
  }

  return JSON.parse(JSON.stringify(value)) as T
}

export default function Home() {
  const [chatInput, setChatInput] = useLocalStorage('chat', '')
  const [files, setFiles] = useState<File[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<'auto' | TemplateId>(
    'auto',
  )
  const [languageModel, setLanguageModel] = useLocalStorage<LLMModelConfig>(
    'languageModel',
    {
      model: 'models/gemini-2.0-flash',
    },
  )

  const posthog = usePostHog()

  const [result, setResult] = useState<ExecutionResult>()
  const [messages, setMessages] = useState<Message[]>([])
  const [fragment, setFragment] = useState<DeepPartial<FragmentSchema>>()
  const [currentTab, setCurrentTab] = useState<'code' | 'fragment'>('code')
  const [isPreviewLoading, setIsPreviewLoading] = useState(false)
  const [isRateLimited, setIsRateLimited] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [isPaymentOpen, setIsPaymentOpen] = useState(false)
  const [isPaid, setIsPaid] = useLocalStorage<boolean>('isPaid', false)
  const [freePromptsUsed, setFreePromptsUsed] = useLocalStorage<number>('freePromptsUsed', 0)

  // Projects state
  const [projects, setProjectsLS] = useLocalStorage<Project[]>('projects', [])
  const [currentProjectId, setCurrentProjectIdLS] = useLocalStorage<string>('currentProjectId', '')
  const [isProjectsOpen, setIsProjectsOpen] = useState(false)

  const setProjects = (p: Project[]) => setProjectsLS(p)
  const setCurrentProjectId = (id: string) => setCurrentProjectIdLS(id)
  const { user, isSignedIn } = useUser()
  const { signOut, getToken } = useClerkAuth()

  const sessionLike = user
    ? ({
        user: {
          id: user.id,
          email: user.primaryEmailAddress?.emailAddress,
          user_metadata: { avatar_url: user.imageUrl },
        },
        access_token: undefined,
      } as any)
    : null
  const [useMorphApply, setUseMorphApply] = useLocalStorage(
    'useMorphApply',
    process.env.NEXT_PUBLIC_USE_MORPH_APPLY === 'true',
  )

  // Per-project persistence helpers
  function projectStateKey(id: string) {
    return `project:${id}:state`
  }
  function getCurrentProjectState() {
    return {
      messages,
      fragment,
      result,
      currentTab,
      chatInput,
    }
  }
  function loadProjectState(id: string) {
    try {
      const raw = localStorage.getItem(projectStateKey(id))
      if (!raw) {
        clearWorkingState()
        return
      }
      const s = JSON.parse(raw)
      setMessages(s.messages || [])
      setFragment(s.fragment)
      setResult(s.result)
      setCurrentTab(s.currentTab || 'code')
      setChatInput(s.chatInput || '')
      setIsPreviewLoading(false)
    } catch {
      clearWorkingState()
    }
  }
  function saveProjectState(id: string, state = getCurrentProjectState()) {
    try {
      localStorage.setItem(projectStateKey(id), JSON.stringify(state))
    } catch {}
  }
  const prevProjectId = useRef<string>('')
  useEffect(() => {
    if (!currentProjectId) return
    if (prevProjectId.current && prevProjectId.current !== currentProjectId) {
      saveProjectState(prevProjectId.current)
    }
    loadProjectState(currentProjectId)
    prevProjectId.current = currentProjectId
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProjectId])
  useEffect(() => {
    if (!currentProjectId) return
    const t = setTimeout(() => saveProjectState(currentProjectId), 250)
    return () => clearTimeout(t)
  }, [messages, fragment, result, currentTab, chatInput, currentProjectId])

  const filteredModels = modelsList.models.filter((model) => {
    if (process.env.NEXT_PUBLIC_HIDE_LOCAL_MODELS) {
      return model.providerId !== 'ollama'
    }
    return true
  })

  // Ensure at least one default project exists
  useEffect(() => {
    if (projects.length === 0) {
      const now = Date.now()
      const defaultProject: Project = {
        id: `${now}-default`,
        name: 'Untitled Project',
        createdAt: now,
        updatedAt: now,
      }
      setProjects([defaultProject])
      setCurrentProjectId(defaultProject.id)
    } else if (!currentProjectId || !projects.find((p) => p.id === currentProjectId)) {
      setCurrentProjectId(projects[0].id)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const currentModel = filteredModels.find(
    (model) => model.id === languageModel.model,
  )

  // Fallback if a stale/invalid model id is in localStorage
  useEffect(() => {
    if (!currentModel) {
      const fallback = filteredModels.find(
        (m) => m.providerId === 'anthropic',
      ) || filteredModels[0]
      if (fallback) {
        setLanguageModel((prev) => ({ ...prev, model: fallback.id }))
      }
    }
  }, [currentModel, filteredModels, setLanguageModel])
  const currentTemplate =
    selectedTemplate === 'auto'
      ? templates
      : { [selectedTemplate]: templates[selectedTemplate] }
  const lastMessage = messages[messages.length - 1]

  // Determine which API to use based on morph toggle and existing fragment
  const shouldUseMorph =
    useMorphApply && fragment && typeof fragment.code === 'string' && fragment.file_path
  const apiEndpoint = shouldUseMorph ? '/api/morph-chat' : '/api/chat'

  const { object, submit, isLoading, stop, error } = useObject({
    api: apiEndpoint,
    schema,
    onError: (error) => {
      console.error('Error submitting request:', error)
      if (error.message?.toLowerCase?.().includes('limit')) {
        setIsRateLimited(true)
      }
      setIsPreviewLoading(false)
      setErrorMessage(error.message || 'Request failed')
    },
    onFinish: async ({ object: fragment, error }) => {
      if (!error) {
        // send it to /api/sandbox
        console.log('fragment', fragment)
        setIsPreviewLoading(true)
        posthog.capture('fragment_generated', {
          template: fragment?.template,
        })

        try {
          const response = await fetch('/api/sandbox', {
            method: 'POST',
            body: JSON.stringify({
              fragment,
              userID: user?.id,
              teamID: undefined,
              accessToken: undefined,
            }),
          })

          if (!response.ok) {
            const text = await response.text()
            throw new Error(text || `Sandbox error (${response.status})`)
          }

          const result = await response.json()
          console.log('result', result)
          posthog.capture('sandbox_created', { url: result.url })

          setResult(result)
          setCurrentPreview({ fragment, result })
          setMessage({ result: cloneDeep(result) })
          setCurrentTab('fragment')
        } catch (e: any) {
          console.error('Sandbox failed:', e)
          setErrorMessage(e.message || 'Preview failed to start.')
        } finally {
          setIsPreviewLoading(false)
        }
      }
    },
  })

  useEffect(() => {
    if (object) {
      const fragmentCopy = cloneDeep(object) as DeepPartial<FragmentSchema>
      setFragment(fragmentCopy)

      const codeSource = fragmentCopy?.code
      const codeText = Array.isArray(codeSource)
        ? codeSource
            .map((f: any) => `// ${f.file_path || f.file_name}\n${f.file_content}`)
            .join('\n\n')
        : typeof codeSource === 'string'
          ? codeSource
          : ''

      const content: Message['content'] = [
        { type: 'text', text: fragmentCopy?.commentary || '' },
      ]

      if (!lastMessage || lastMessage.role !== 'assistant') {
        addMessage({
          role: 'assistant',
          content,
          object: fragmentCopy,
        })
      }

      if (lastMessage && lastMessage.role === 'assistant') {
        setMessage({
          content,
          object: fragmentCopy,
        })
      }
    }
  }, [object])

  useEffect(() => {
    if (error) stop()
  }, [error])

  function setMessage(message: Partial<Message>, index?: number) {
    setMessages((previousMessages) => {
      const updatedMessages = [...previousMessages]
      updatedMessages[index ?? previousMessages.length - 1] = {
        ...previousMessages[index ?? previousMessages.length - 1],
        ...message,
      }

      return updatedMessages
    })
  }

  async function handleSubmitAuth(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()

    const reachedFreeLimit = !isPaid && freePromptsUsed >= 3

    if (reachedFreeLimit) {
      setIsPaymentOpen(true)
      setErrorMessage('Subscription required to continue.')
      return
    }

    if (!currentModel) {
      setErrorMessage('Selected model is unavailable. Switched to a default model, please try again.')
      return
    }

    if (isLoading) {
      stop()
    }

    const content: Message['content'] = [{ type: 'text', text: chatInput }]
    const images = await toMessageImage(files)

    if (images.length > 0) {
      images.forEach((image) => {
        content.push({ type: 'image', image })
      })
    }

    const updatedMessages = addMessage({
      role: 'user',
      content,
    })

    submit({
      userID: user?.id,
      teamID: undefined,
      messages: toAISDKMessages(updatedMessages),
      template: currentTemplate,
      model: currentModel,
      config: languageModel,
      ...(shouldUseMorph && fragment ? { currentFragment: fragment } : {}),
    })

    if (!isPaid) setFreePromptsUsed((prev) => prev + 1)

    setChatInput('')
    setFiles([])
    setCurrentTab('code')

    posthog.capture('chat_submit', {
      template: selectedTemplate,
      model: languageModel.model,
    })
  }

  function retry() {
    submit({
      userID: user?.id,
      teamID: undefined,
      messages: toAISDKMessages(messages),
      template: currentTemplate,
      model: currentModel,
      config: languageModel,
      ...(shouldUseMorph && fragment ? { currentFragment: fragment } : {}),
    })
  }

  function addMessage(message: Message) {
    setMessages((previousMessages) => [...previousMessages, message])
    return [...messages, message]
  }

  function handleSaveInputChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setChatInput(e.target.value)
  }

  function handleFileChange(change: SetStateAction<File[]>) {
    setFiles(change)
  }

  function logout() {
    void signOut()
  }

  function handleLanguageModelChange(e: LLMModelConfig) {
    setLanguageModel({ ...languageModel, ...e })
  }

  function handleProjectSwitched() {
    // State will be saved/loaded by currentProjectId effect
  }

  function handleSocialClick(target: 'github' | 'x' | 'discord') {
    if (target === 'github') {
      window.open('https://github.com/e2b-dev/fragments', '_blank')
    } else if (target === 'x') {
      window.open('https://x.com/e2b', '_blank')
    } else if (target === 'discord') {
      window.open('https://discord.gg/e2b', '_blank')
    }

    posthog.capture(`${target}_click`)
  }

  function clearWorkingState() {
    stop()
    setChatInput('')
    setFiles([])
    setMessages([])
    setFragment(undefined)
    setResult(undefined)
    setCurrentTab('code')
    setIsPreviewLoading(false)
  }

  function handleClearChat() {
    clearWorkingState()
  }

  function setCurrentPreview(preview: {
    fragment: DeepPartial<FragmentSchema> | undefined
    result: ExecutionResult | undefined
  }) {
    setFragment(preview.fragment ? cloneDeep(preview.fragment) : undefined)
    setResult(preview.result ? cloneDeep(preview.result) : undefined)
  }

  function handleUndo() {
    setMessages((previousMessages) => [...previousMessages.slice(0, -2)])
    setCurrentPreview({ fragment: undefined, result: undefined })
  }

  return (
    <main className="flex min-h-screen max-h-screen">
      <SignedOut>
        <ClerkAuthOverlay />
      </SignedOut>
      <div className="grid w-full md:grid-cols-2">
        <div
          className={`flex flex-col w-full max-h-full max-w-[800px] mx-auto px-4 overflow-auto ${fragment ? 'col-span-1' : 'col-span-2'}`}
        >
          <NavBar
            session={sessionLike}
            showLogin={() => {}}
            signOut={logout}
            onSocialClick={handleSocialClick}
            onClear={handleClearChat}
            canClear={messages.length > 0}
            canUndo={messages.length > 1 && !isLoading}
            onUndo={handleUndo}
            onProjectsClick={() => setIsProjectsOpen(true)}
            currentProjectName={projects.find((p) => p.id === currentProjectId)?.name}
          />
          <Chat
            messages={messages}
            isLoading={isLoading}
            setCurrentPreview={setCurrentPreview}
          />
          <ChatInput
            retry={retry}
            isErrored={error !== undefined}
            errorMessage={errorMessage}
            isLoading={isLoading}
            isRateLimited={isRateLimited}
            stop={stop}
            input={chatInput}
            handleInputChange={handleSaveInputChange}
            handleSubmit={handleSubmitAuth}
            isMultiModal={false}
            files={files}
            handleFileChange={handleFileChange}
          >
            <ChatPicker
              templates={templates}
              selectedTemplate={selectedTemplate}
              onSelectedTemplateChange={setSelectedTemplate}
            />
          </ChatInput>
        </div>
        {(() => {
          const assistantWithObject = [...messages].reverse().find((m) => m.role === 'assistant' && (m as any).object)
          const assistantWithResult = [...messages].reverse().find((m) => (m as any).result)
          const derivedFragment = (fragment ?? (assistantWithObject as any)?.object) as DeepPartial<FragmentSchema> | undefined
          const derivedResult = (result ?? (assistantWithResult as any)?.result) as ExecutionResult | undefined
          return (
            <Preview
              teamID={undefined}
              accessToken={undefined}
              selectedTab={currentTab}
              onSelectedTabChange={setCurrentTab}
              isChatLoading={isLoading}
              isPreviewLoading={isPreviewLoading}
              fragment={derivedFragment}
              result={derivedResult}
              onClose={() => setFragment(undefined)}
            />
          )
        })()}
        <ProjectSidebar
          open={isProjectsOpen}
          onOpenChange={setIsProjectsOpen}
          projects={projects}
          setProjects={setProjects}
          currentProjectId={currentProjectId}
          setCurrentProjectId={setCurrentProjectId}
          onProjectSwitched={handleProjectSwitched}
        />
      </div>
      <PaymentDialog open={isPaymentOpen} onOpenChange={setIsPaymentOpen} />
    </main>
  )
}
