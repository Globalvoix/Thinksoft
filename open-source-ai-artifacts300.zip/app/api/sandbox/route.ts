import { FragmentSchema } from '@/lib/schema'
import { ExecutionResultInterpreter, ExecutionResultWeb } from '@/lib/types'
import templates from '@/lib/templates'
import { Sandbox } from '@e2b/code-interpreter'

const sandboxTimeout = 10 * 60 * 1000 // 10 minute in ms

export const maxDuration = 300

export async function POST(req: Request) {
  try {
    const {
      fragment,
      userID,
      teamID,
      accessToken,
    }: {
      fragment: FragmentSchema
      userID: string | undefined
      teamID: string | undefined
      accessToken: string | undefined
    } = await req.json()
    console.log('fragment', fragment)
    console.log('userID', userID)

    const sbx = await Sandbox.create(fragment.template, {
      metadata: {
        template: fragment.template,
        userID: userID ?? '',
        teamID: teamID ?? '',
      },
      timeoutMs: sandboxTimeout,
      ...(teamID && accessToken
        ? {
            headers: {
              'X-Supabase-Team': teamID,
              'X-Supabase-Token': accessToken,
            },
          }
        : {}),
    })

    // Copy code to fs
    if (Array.isArray(fragment.code)) {
      await Promise.all(
        fragment.code.map(async (file) => {
          await sbx.files.write(file.file_path, file.file_content)
          console.log(`Copied file to ${file.file_path} in ${sbx.sandboxId}`)
        }),
      )
    } else {
      await sbx.files.write(fragment.file_path, fragment.code)
      console.log(`Copied file to ${fragment.file_path} in ${sbx.sandboxId}`)
    }

    const packageJsonProvided = Array.isArray(fragment.code)
      ? fragment.code.some(
          (file) => file.file_path === 'package.json' || file.file_name === 'package.json',
        )
      : fragment.file_path === 'package.json'

    if (fragment.has_additional_dependencies) {
      try {
        await sbx.commands.run(fragment.install_dependencies_command)
        console.log(
          `Installed dependencies: ${fragment.additional_dependencies.join(', ')} in sandbox ${sbx.sandboxId}`,
        )
      } catch (e) {
        console.warn('Dependency install failed, continuing:', e)
      }
    }

    if (packageJsonProvided) {
      try {
        await sbx.commands.run('npm install')
        console.log(`Installed package.json dependencies in sandbox ${sbx.sandboxId}`)
      } catch (e) {
        console.warn('npm install failed, continuing:', e)
      }
    }

    // Execute code or return a URL to the running sandbox
    if (fragment.template === 'code-interpreter-v1') {
      const runContent = Array.isArray(fragment.code)
        ? fragment.code[0]?.file_content || ''
        : fragment.code || ''
      const { logs, error, results } = await sbx.runCode(runContent)

      return new Response(
        JSON.stringify({
          sbxId: sbx?.sandboxId,
          template: fragment.template,
          stdout: logs.stdout,
          stderr: logs.stderr,
          runtimeError: error,
          cellResults: results,
        } as ExecutionResultInterpreter),
      )
    }

    const tplPort = (templates as any)[fragment.template]?.port || 3000
    const port = fragment.port ?? tplPort
    const host = `https://${sbx?.getHost(port)}`

    // Wait for server readiness (best-effort)
    try {
      const maxAttempts = 240
      for (let i = 0; i < maxAttempts; i++) {
        try {
          const res = await fetch(host, { method: 'GET', cache: 'no-store' })
          if (res.status >= 200 && res.status < 400) break
        } catch {}
        await new Promise((r) => setTimeout(r, 500))
      }
    } catch (e) {
      console.warn('Readiness check failed, returning URL anyway', e)
    }

    return new Response(
      JSON.stringify({
        sbxId: sbx?.sandboxId,
        template: fragment.template,
        url: host,
      } as ExecutionResultWeb),
    )
  } catch (e: any) {
    console.error('Sandbox error:', e)
    return new Response(
      JSON.stringify({ error: String(e?.message || e) }),
      { status: 500, headers: { 'content-type': 'application/json' } },
    )
  }
}
