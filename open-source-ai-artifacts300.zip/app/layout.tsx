import './globals.css'
import { PostHogProvider, ThemeProvider } from './providers'
import { Toaster } from '@/components/ui/toaster'
import { Analytics } from '@vercel/analytics/next'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ClerkProvider } from '@clerk/nextjs'
import Script from 'next/script'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Thinksoft',
  description: 'Thinksoft',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <ClerkProvider>
        <PostHogProvider>
          <body className={inter.className}>
            <Script
              src="https://www.paypal.com/sdk/js?client-id=BAAjWix4xSo6YZnIer-kgARDBmZq59PCw2SCYO_MZRi70Bar9GISKdK4KYg8sd7zEssQNyQIbACn4rTAEs&components=hosted-buttons&disable-funding=venmo&currency=USD"
              crossOrigin="anonymous"
              strategy="afterInteractive"
            />
            <ThemeProvider
              attribute="class"
              defaultTheme="dark"
              enableSystem
              disableTransitionOnChange
            >
              {children}
            </ThemeProvider>
            <Toaster />
            <Analytics />
          </body>
        </PostHogProvider>
      </ClerkProvider>
    </html>
  )
}
